package org.firstinspires.ftc.teamcode.MAIN;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.MAIN.Hardware;


@TeleOp(name = "ShooterTest")
public class ShooterTest extends LinearOpMode {
    public double close1_pos, close2_pos, far1_pos;
    public double pos;
    public double pow;

    public double shooter_pow_c1, shooter_pow_c2, shooter_pow_f1;
    @Override
    public void runOpMode() throws InterruptedException {
        Hardware hardware = new Hardware(hardwareMap);
        waitForStart();

        // Run until the op mode is stopped
        while (opModeIsActive()) {
            hardware.hood.setPosition(pos);
            hardware.outtake_bottom.setPower(pow);
            hardware.outtake_top.setPower(pow);

        }

    }

}
