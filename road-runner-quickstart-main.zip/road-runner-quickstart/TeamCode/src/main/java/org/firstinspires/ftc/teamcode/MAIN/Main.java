package org.firstinspires.ftc.teamcode.MAIN;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Gamepad;
import org.firstinspires.ftc.teamcode.MAIN.Hardware;
import org.firstinspires.ftc.teamcode.MAIN.Constants;

@TeleOp(name = "RuckusTeleOp")
public class Main extends LinearOpMode {

    public static double turretpos1, turretpos2;
    public double close1_pos, close2_pos, far1_pos = 0.1;

    public double shooter_pow_c1, shooter_pow_c2, shooter_pow_f1;
    public double back, front;


    @Override
    public void runOpMode() throws InterruptedException {

        // Initialize motors from hardware map
        Hardware hardware = new Hardware(hardwareMap);

        Gamepad currentGamepad1 = new Gamepad();
        Gamepad currentGamepad2 = new Gamepad();

        Gamepad prevGamepad1 = new Gamepad();
        Gamepad prevGamepad2 = new Gamepad();

        waitForStart();

        // Run until the op mode is stopped
        while (opModeIsActive()) {
            prevGamepad1.copy(currentGamepad1);
            prevGamepad2.copy(currentGamepad2);

            currentGamepad1.copy(gamepad1);
            currentGamepad2.copy(gamepad2);


            //drivetrain
            double x = -currentGamepad1.left_stick_x;
            double y = currentGamepad1.left_stick_y;
            double r = -0.5*currentGamepad1.right_stick_x;

            //parabolic smoothing thingy
            x = (Math.cosh(x*Math.sqrt(Math.sqrt(Math.pow(x,2))))-1)*Math.signum(x);
            y = (Math.cosh(y*Math.sqrt(Math.sqrt(Math.pow(y,2))))-1)*Math.signum(y);

            //
            hardware.FL.setPower(y+x+r);
            hardware.FR.setPower(y-x-r);
            hardware.BL.setPower(y-x+r);
            hardware.BR.setPower(y+x-r);

            // Tank drive control (left stick Y controls left side, right stick Y controls right side)

            if (currentGamepad1.right_trigger>0.25){
                hardware.intake.setPower(0.6);
            }

            if(currentGamepad2.y){
                hardware.hood.setPosition(close1_pos);


            }else if(currentGamepad2.b){
                hardware.hood.setPosition(close2_pos);
            }else if(currentGamepad2.a){
                hardware.hood.setPosition(far1_pos);
            }





            telemetry.update();
        }
    }
}
