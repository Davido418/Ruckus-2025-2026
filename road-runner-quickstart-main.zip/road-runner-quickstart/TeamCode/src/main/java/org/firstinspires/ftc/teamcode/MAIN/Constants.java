package org.firstinspires.ftc.teamcode.MAIN;

public class Constants {
    public double close1_pos, close2_pos, far1_pos;
    public double back, front;
}
